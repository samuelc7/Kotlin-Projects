enum class StockingMessage {
    succes, notInInventory, notEnoughInInventory, invalidNDCFormat
}